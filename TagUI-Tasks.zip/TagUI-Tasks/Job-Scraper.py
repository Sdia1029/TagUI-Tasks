import os
import smtplib, ssl
from dotenv import load_dotenv
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import tagui as t
import openai

# --- Load credentials from .env ---
load_dotenv()
sender_email = os.getenv("EMAIL_ADDRESS")
sender_password = os.getenv("EMAIL_PASSWORD")
groq_api_key = os.getenv("GROQ_API_KEY")

# --- User Input ---
Job_Title = input("Enter the term for which you want to search the job: ").strip()
City = input("Enter the city name (e.g Lahore): ").strip().lower()
receiver_email = input("Enter the recipient Email: ").strip()

# --- Scrape Page using TagUI ---
t.init(visual_automation=True)
t.url("https://www.mustakbil.com/")
t.wait(5)
t.type('//*[@id="keywords"]', Job_Title)
t.type('//*[@id="location"]', City)
t.click('//*[@id="top"]/ng-component/div[1]/div/div/div/div[1]/form/div/button/span')
t.wait(8)
page_text = t.read('//body')
t.close()
print("===== Job Search Completed =====")

# --- Use GenAI to extract only matching jobs ---
openai.api_key = groq_api_key
openai.api_base = "https://api.groq.com/openai/v1"

def extract_matching_jobs(raw_text, job_title, city):
    prompt = f"""
You are an expert job assistant. From the text below, extract only jobs that match the title '{job_title}' and are located in '{city}'.

For each job, provide:

**Job Title:** [title]  
**Company:** [company]  
**Type:** [type]  
**Location:** [location]

No numbering, no emojis, no summary. Limit to max 3 jobs.

Text:
\"\"\"{raw_text[:4000]}\"\"\"
"""
    try:
        response = openai.ChatCompletion.create(
            model="llama3-8b-8192",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.2,
        )
        return response.choices[0].message.content.strip()
    except Exception as e:
        return f"Error from GenAI: {e}"

ai_filtered_jobs = extract_matching_jobs(page_text, Job_Title, City)
print("=== AI Filtered Jobs ===")
print(ai_filtered_jobs)
print("===========================")

# --- Format Email ---
def format_email_body(title, city, jobs_text, found=True):
    jobs_html = jobs_text.replace("**", "<b>").replace(":</b>", ":</b> ")  # Ensure spacing
    # Split jobs by double newlines
    jobs_list = [j.strip() for j in jobs_html.split("\n\n") if j.strip()]
    numbered_jobs = ""
    for idx, job in enumerate(jobs_list, 1):
        numbered_jobs += f"<p><b>Job {idx}:</b><br>{job}</p>"

    if found:
        return f"""<p>Dear User,</p>
<p>Here are the jobs for "<b>{title}</b>" in <b>{city.title()}</b>:</p>
{numbered_jobs}
<p>Best regards,<br>Your Job Finder Bot</p>"""
    else:
        return f"""<p>Dear User,</p>
<p>Unfortunately, no job listings were found for "<b>{title}</b>" in <b>{city.title()}</b>.</p>
<p>Please try again later or use broader keywords.</p>
<p>Best regards,<br>Your Job Finder Bot</p>"""

# --- Send Email ---
def send_email(subject, body):
    msg = MIMEMultipart()
    msg['From'] = sender_email
    msg['To'] = receiver_email
    msg['Subject'] = subject
    msg.attach(MIMEText(body, 'html'))

    context = ssl.create_default_context()
    with smtplib.SMTP_SSL("smtp.gmail.com", 465, context=context) as server:
        server.login(sender_email, sender_password)
        server.send_message(msg)

# --- Decide and Send ---
if "Error" not in ai_filtered_jobs and len(ai_filtered_jobs) > 10:
    formatted_body = format_email_body(Job_Title, City, ai_filtered_jobs, found=True)
    send_email(f"Jobs for {Job_Title.title()} in {City.title()}", formatted_body)
    print("===== Email sent with filtered jobs =====")
else:
    formatted_body = format_email_body(Job_Title, City, ai_filtered_jobs, found=False)
    send_email(f"No Jobs Found - {Job_Title.title()}", formatted_body)
    print("===== No matching jobs found. Notification sent =====")
