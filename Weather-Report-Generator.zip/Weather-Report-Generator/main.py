import os
import tagui as t
from fpdf import FPDF
import smtplib
from email.message import EmailMessage
from datetime import datetime, timedelta
from dotenv import load_dotenv
import random

load_dotenv()

# ----------------------------
# USER INPUTS
# ----------------------------

city = input("Enter your city(e.g lahore,islamabad,karachi): ")
forecast_type = input("Choose forecast type (today, daily, monthly): ").lower()
receiver_email = input("Enter your email: ")

# ----------------------------
# TagUI WEB SCRAPING
# ----------------------------

t.init(visual_automation=True)
t.url("https://www.accuweather.com/")

search_xpath = '/html/body/div[1]/div[1]/div[3]/div/div[1]/div[1]/form/input'

if t.exist(search_xpath):
    print("Search box found.")
    t.type(search_xpath, city)
    t.keyboard('[enter]')
    t.wait(5)
else:
    print("Search box not found.")
    t.close()
    exit()

# ----------------------------
# Dummy weather data
# ----------------------------

dates = []
temps = []
conditions = []
condition_options = ["Sunny", "Partly Cloudy", "Cloudy", "Rainy"]

if forecast_type == "today":
    dates = [datetime.now().strftime('%d %B %Y')]
    temps = [f"{random.randint(30, 37)}° C"]
    conditions = [random.choice(condition_options)]

elif forecast_type == "daily":
    today = datetime.now()
    for i in range(5):
        day = today + timedelta(days=i)
        dates.append(day.strftime("%A"))
        temps.append(f"{random.randint(30, 37)}° C")
        conditions.append(random.choice(condition_options))

elif forecast_type == "monthly":
    today = datetime.now()
    days_in_month = 31
    for i in range(1, days_in_month + 1):
        dates.append(f"{i} {today.strftime('%B')}")
        temps.append(f"{random.randint(30, 37)}° C")
        conditions.append(random.choice(condition_options))
else:
    print("Invalid forecast type.")
    t.close()
    exit()
t.close()

print(f"Sample Dates: {dates[:5]}...")
print(f"Sample Temps: {temps[:5]}...")
print(f"Sample Conditions: {conditions[:5]}...")

# ----------------------------
# Generate PDF Report
# ----------------------------

pdf = FPDF()
pdf.add_page()
pdf.set_font("Arial", size=12)
pdf.cell(0, 10, f"City: {city.title()}", ln=True)
pdf.cell(0, 10, f"Forecast Type: {forecast_type.title()}", ln=True)
pdf.ln(5)

pdf.set_font("Arial", "B", size=12)
pdf.cell(50, 10, "Date/Day", 1)
pdf.cell(40, 10, "Temp", 1)
pdf.cell(60, 10, "Condition", 1)
pdf.ln()

pdf.set_font("Arial", size=12)
for d, temp, cond in zip(dates, temps, conditions):
    pdf.cell(50, 10, d, 1)
    pdf.cell(40, 10, temp, 1)
    pdf.cell(60, 10, cond, 1)
    pdf.ln()

pdf_name = f"{city.lower()}_weather_report.pdf"
pdf.output(pdf_name)
print(f"PDF generated: {pdf_name}")

# ----------------------------
# Prepare Professional Email Body
# ----------------------------

avg_temp = sum([int(t.split('°')[0]) for t in temps]) / len(temps)
most_common = max(set(conditions), key=conditions.count)

email_body = f"""Dear Recipient,

Please find below the {forecast_type} weather forecast for {city.title()}.

Summary:
- Average Temperature: {avg_temp:.1f}°C
- Predominant Condition: {most_common}

Forecast Details:
{'Date/Day':<15} {'Temp':<10} {'Condition'}
{'-'*40}
"""

for d, temp, cond in zip(dates, temps, conditions):
    email_body += f"{d:<15} {temp:<10} {cond}\n"

email_body += f"""

A detailed PDF report is also attached for your reference.

Best regards,
Your Automated Weather Assistant
"""


# ----------------------------
# Send Email with PDF
# ----------------------------

msg = EmailMessage()
msg["Subject"] = f"{city.title()} Weather Report"
msg["From"] = os.getenv("EMAIL_ADDRESS")
msg["To"] = receiver_email
msg.set_content(email_body)

with open(pdf_name, "rb") as f:
    pdf_data = f.read()
    msg.add_attachment(pdf_data, maintype="application", subtype="pdf", filename=pdf_name)

try:
    with smtplib.SMTP_SSL("smtp.gmail.com", 465) as smtp:
        smtp.login(os.getenv("EMAIL_ADDRESS"), os.getenv("EMAIL_PASSWORD"))
        smtp.send_message(msg)
    print(f"Email sent to {receiver_email} successfully.")
except Exception as e:
    print("Email sending failed:", e)
